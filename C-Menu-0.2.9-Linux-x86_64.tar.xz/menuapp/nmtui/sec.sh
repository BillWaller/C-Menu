nmcli --show-secrets connection show wlp6s0 |
    sed -n '/^connection\.id:/p
        /^802-11-wireless.mode:/p
        /^802-11-wireless.ssid:/p
        /^802-11-wireless-security/p
        /^GENERAL.NAME:/p
        /^GENERAL.DEVICES:/p
        /^GENERAL.STATE:/p
        /^ipv4.method:/p
        /^IP4.ADDRESS\[1\]:/p
        /^IP4.GATEWAY:/p
        /^IP4.ROUTE/p
        /^IP4.DNS/p
        /^ipv6.method:/p
        /^IP6.ADDRESS/p
        /^IP6.GATEWAY:/p
        /^IP6.ROUTE/p
        /^IP6.DNS/p' |
    sed '/ \-\-$/d
        / 0$/d
        /0 /d'
