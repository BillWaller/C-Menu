:   NetworkManager TUI
#
:   Edit a connection
!exec nmtui-edit-connection
:   Activate a connection
!exec nmtui-activate-connection
:   Set system hostname
!exec nmtui-hostname
:   Set Wi-Fi password
!exec nmtui-wifi-password
:   Exit NetworkManager TUI
!return
