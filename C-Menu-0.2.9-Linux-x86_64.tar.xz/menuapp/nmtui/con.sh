#!/bin/bash

nmcli -t c
exit 0
| grep -E 'ethernet|wifi' | awk '{print $1}' | while read -r con; do
    echo "Connection: $con"
    nmcli connection show "$con" | grep -E 'ipv4.addresses|ipv6.addresses'
done
