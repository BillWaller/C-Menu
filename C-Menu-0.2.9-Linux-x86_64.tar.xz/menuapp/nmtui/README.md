# Network Manager Tools

This repository contains tools and scripts for managing and configuring network settings on various operating systems. The tools are designed to simplify the process of network management, including tasks such as IP configuration, DNS settings, and network diagnostics.

However, I have not even started on it yet. Before I begin projects like this, I
need to finish debugging C-Menu. If someone wants to tackle this project, it
would be a candidate for inclusion into the C-Menu distribution.
