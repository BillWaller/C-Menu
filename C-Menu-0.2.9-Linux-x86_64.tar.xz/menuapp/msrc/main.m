:                APPLICATIONS
#
:     Neovim
!exec nvim
:     Root Neovim
!exec rsh -c nvim
:     Full Screen (root) Shell
!exec rsh
:   Workstation Configuration
!menu workstation_config.m
:   Diagnostic Tools
!menu diag.m
:     Installment Loan Calculations
!form iloan.f -i iloan.dat -S iloan -o iloan.dat
:     Listener Research
!form listadd.f -i listadd.dat -o listadd.dat
:     Cash Receipts
!form receipt.f -i receipt.dat -o receipt.dat
:     Form Data Types
!form -d fields.f -i fields.dat -o fields.dat
:     Edit .c Files in Current Directory
!pick -S project_src -c nvim -T "Project Tree - Select File to Edit"
:     View CMenu Source with Tree-Sitter
!pick -S project_src -n 1 -T "Select Project File to Highlight" -c "view -L 60 -C 70 -S \"tree-sitter highlight %%\""
:     View Rust Source with Tree-Sitter
!pick -S rust_src -n 1 -T "Select Rust File to Highlight" -c "view -L 60 -C 70 -S \"tree-sitter highlight %%\""
:     View Data Types Help File
!view -T "Data Types" /home/bill/menuapp/help/fields.hlp
:     Menu Description With Bat Syntax Highlighting
!view -L 30 -C 75 -S "bat --theme ansi -l Crystal -f /home/bill/menuapp/msrc/main.m"
:     View C-Menu Command Line Options
!view -L 62 -C 75 -S options
:     View Highlighted view_engine.c
!view -L 60 -C 70 ~/menuapp/help/view_engine.c
:     Help
!help
:     Exit Applications
!return
