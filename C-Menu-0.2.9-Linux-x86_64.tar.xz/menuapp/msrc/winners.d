H~Contest Winners
T~02~11~     Name:
T~03~11~  Address:
T~04~11~    Phone:
T~05~11~    Email:
T~06~11~  Website:
T~07~11~   Github:
T~08~11~  Twitter:
T~09~11~ LinkedIn:
T~10~11~   Amount:
F~02~22~36~1
F~03~22~36~1
F~04~22~36~1
F~05~22~36~1
F~06~22~36~1
F~07~22~36~1
F~08~22~36~1
F~09~22~36~1
F~10~22~36~1
<-~/menuapp/data/winners.in
>-~/menuapp/data/winners.out
??~/menuapp/help/winners.help
